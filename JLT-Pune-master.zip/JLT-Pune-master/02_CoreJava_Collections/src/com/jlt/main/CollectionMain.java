package com.jlt.main;

import com.jlt.demo.ArrayListDemo;
import com.jlt.demo.HashMapDemo;
import com.jlt.demo.HashSetDemo;
import com.jlt.demo.TreeMapDemo;
import com.jlt.demo.TreeSetDemo;

public class CollectionMain {
	public static void main(String[] args) {
//		ArrayListDemo arrayListDemo = new ArrayListDemo();
//		arrayListDemo.print();

//		HashSetDemo demo = new HashSetDemo();
//		demo.printSet();

//		TreeSetDemo demo = new TreeSetDemo();
//		demo.display();

//		HashMapDemo demo = new HashMapDemo();
//		demo.printMap();
		
		TreeMapDemo demo = new TreeMapDemo();
		demo.print();
	}
}
